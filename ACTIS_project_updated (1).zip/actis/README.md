# ACTIS — Advanced Cyber Threat Intelligence System

A full working implementation of the project described in the synopsis
*"Advanced Cyber Threat Intelligence System"* (Pavana S, MCA IV-Sem,
Dhanwantari Academy for Management Studies, Guide: Prof. Swathi N M).

It is a Flask + Machine Learning web application that simulates/accepts
network-traffic and log data, classifies it into threat categories with
a confidence score and risk score, correlates it with the MITRE ATT&CK
framework, raises alerts, and gives analysts a dashboard, searchable
threat history, and PDF/Excel reporting — matching every feature and
objective listed in the synopsis.

## 1. How this maps to the synopsis

| Synopsis objective | Implementation |
|---|---|
| Collect & aggregate multi-source data (network/endpoint logs, OSINT) | `simulate_traffic_sample()` in `app.py` stands in for a live Scapy/PyShark capture feed; manual-entry form on `/detect` represents ingesting an external log/OSINT record |
| Unified data processing / normalization pipeline | `StandardScaler` pipeline in `ml_model/train_model.py`, applied identically at inference time |
| ML & behavioral analytics, incl. anomaly/zero-day style detection | `RandomForestClassifier` (`ml_model/train_model.py`) trained on 12 engineered traffic/log features across 6 classes |
| Real-time correlation with STIX/TAXII & MITRE ATT&CK | `database.py: MITRE_MAP` — every prediction is tagged with a technique ID (e.g. T1498 for DDoS) |
| Risk-scoring & alert prioritization | `risk_score_from()` in `app.py` — combines model confidence with a class severity weight into a 0–100 score |
| Interactive visualization dashboard | `/dashboard` — Chart.js bar/doughnut/line charts + live stat cards |
| Automated/semi-automated response | `RECOMMENDED_ACTIONS` mapping surfaced on every alert; status workflow (Open → Investigating → Resolved) |
| Scalable, on-prem or cloud deployable | Stateless Flask app + SQLite (swap for Postgres/MySQL by changing `database.py`'s connection function only) |
| Analyst feedback / retraining loop | `ml_model/train_model.py` is a standalone, re-runnable training script — new labeled data can be appended to `generate_dataset()` (or swapped for a CSV loader) and the model retrained with one command |

## 2. Tech stack (matches the synopsis's "Tools and Technologies")

- **Frontend:** HTML5, Bootstrap 5, JavaScript, Chart.js
- **Backend:** Python, Flask
- **Machine Learning:** scikit-learn (RandomForest), pandas, NumPy
- **Database:** SQLite
- **Reporting:** ReportLab (PDF), OpenPyXL (Excel)

> Note: the synopsis also lists Scapy/PyShark for live packet capture and
> VirusTotal/AbuseIPDB for threat-intel enrichment. Those require live
> network access and external API keys, which aren't available in this
> environment — `simulate_traffic_sample()` is a clearly-marked stand-in
> so the rest of the pipeline (ML → risk scoring → MITRE mapping → alert →
> dashboard → report) is fully real and demonstrable. Swapping in a real
> Scapy sniffer or a VirusTotal API call only requires changing that one
> function; nothing downstream needs to change.

## 3. Project structure

```
actis/
├── app.py                     # Flask routes, auth, detection engine, reports
├── database.py                 # SQLite schema, queries, MITRE map
├── requirements.txt
├── ml_model/
│   ├── train_model.py          # synthetic dataset + RandomForest training
│   ├── threat_model.pkl        # trained classifier (generated)
│   ├── scaler.pkl               # feature scaler (generated)
│   ├── label_encoder.pkl        # class label encoder (generated)
│   └── metrics.txt              # last training run's accuracy/report
├── templates/                  # Jinja2 HTML (login, dashboard, detect, alerts, reports)
└── static/css/style.css        # dark security-dashboard theme
```

## 4. Setup & run

```bash
cd actis
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 1. Train the model (creates ml_model/threat_model.pkl etc.)
python3 ml_model/train_model.py

# 2. Run the app (creates actis.db automatically on first run)
python3 app.py
```

Open **http://localhost:5000** and log in with:

```
Username: admin
Password: admin123
```

(Change this immediately in a real deployment — see `database.py: init_db()`.)

## 5. Using the system

1. **Dashboard** — live counts, charts by threat type/severity/day. Use
   "Simulate Live Traffic" to generate N synthetic samples at once (great
   for demos/screenshots).
2. **Threat Detection** — either capture one simulated sample, or type in
   your own 12 feature values (packet count, byte count, failed logins,
   entropy score, etc.) to see the model classify it live, with
   confidence %, risk score, MITRE technique, and recommended action.
3. **Alerts & History** — search by IP/type, filter by threat type /
   severity / status, update investigation status, or delete records.
4. **Reports** — one-click PDF (executive summary) or Excel (full raw
   dataset) export.

## 6. Retraining with your own data

Replace `generate_dataset()` in `ml_model/train_model.py` with a loader
for a real dataset (e.g. CICIDS2017, NSL-KDD, or your organization's own
labeled NetFlow/log export) that produces a DataFrame with the same
`FEATURE_NAMES` columns plus a `label` column, then re-run
`python3 ml_model/train_model.py`. The Flask app will pick up the new
`.pkl` files on next restart — no other code changes required.

## 7. Suggested next steps for the final project report

- Swap `simulate_traffic_sample()` for a real Scapy/PyShark capture loop.
- Add a scheduled job (APScheduler / Celery) to poll VirusTotal/AbuseIPDB
  and enrich alerts automatically.
- Add role-based access control (analyst vs. administrator) — the `role`
  column already exists in the `users` table.
- Containerize with Docker for the "cloud-deployable" objective.
