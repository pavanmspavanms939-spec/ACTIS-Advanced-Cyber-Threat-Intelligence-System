"""
Database layer for the Advanced Cyber Threat Intelligence System.
Uses SQLite for lightweight, zero-config storage (per synopsis: Database -> SQLite).
"""

import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "actis.db")

# Minimal MITRE ATT&CK style mapping so the correlation feature described
# in the synopsis (Objective 4) has something concrete to reference.
MITRE_MAP = {
    "DDoS": ("T1498", "Network Denial of Service"),
    "Malware": ("T1204", "User Execution / Malicious Payload"),
    "Phishing": ("T1566", "Phishing"),
    "Brute_Force": ("T1110", "Brute Force"),
    "Port_Scan": ("T1046", "Network Service Discovery"),
    "Normal": ("-", "No technique - benign traffic"),
}

RECOMMENDED_ACTIONS = {
    "DDoS": "Enable rate limiting / upstream scrubbing; block offending source ranges.",
    "Malware": "Isolate host from network, run full AV/EDR scan, revoke compromised credentials.",
    "Phishing": "Block sender domain, notify affected users, force password reset if clicked.",
    "Brute_Force": "Lock account, enforce MFA, block source IP after threshold.",
    "Port_Scan": "Monitor source IP, tighten firewall rules, verify no follow-up exploitation.",
    "Normal": "No action required.",
}


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'analyst',
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            source_ip TEXT,
            dest_ip TEXT,
            threat_type TEXT NOT NULL,
            severity TEXT NOT NULL,
            confidence REAL NOT NULL,
            risk_score REAL NOT NULL,
            mitre_id TEXT,
            mitre_name TEXT,
            recommended_action TEXT,
            status TEXT DEFAULT 'Open',
            details TEXT
        )
    """)

    conn.commit()

    # Seed a default analyst account if none exists
    cur.execute("SELECT COUNT(*) as c FROM users")
    if cur.fetchone()["c"] == 0:
        cur.execute(
            "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
            ("admin", generate_password_hash("admin123"), "administrator", datetime.now().isoformat()),
        )
        conn.commit()

    conn.close()


def insert_alert(source_ip, dest_ip, threat_type, severity, confidence, risk_score, details=""):
    mitre_id, mitre_name = MITRE_MAP.get(threat_type, ("-", "Unknown"))
    action = RECOMMENDED_ACTIONS.get(threat_type, "Review manually.")
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO alerts
        (timestamp, source_ip, dest_ip, threat_type, severity, confidence, risk_score,
         mitre_id, mitre_name, recommended_action, status, details)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?)
    """, (
        datetime.now().isoformat(), source_ip, dest_ip, threat_type, severity,
        confidence, risk_score, mitre_id, mitre_name, action, details
    ))
    conn.commit()
    alert_id = cur.lastrowid
    conn.close()
    return alert_id


def get_alerts(threat_type=None, severity=None, status=None, search=None):
    conn = get_connection()
    cur = conn.cursor()
    query = "SELECT * FROM alerts WHERE 1=1"
    params = []
    if threat_type and threat_type != "All":
        query += " AND threat_type = ?"
        params.append(threat_type)
    if severity and severity != "All":
        query += " AND severity = ?"
        params.append(severity)
    if status and status != "All":
        query += " AND status = ?"
        params.append(status)
    if search:
        query += " AND (source_ip LIKE ? OR dest_ip LIKE ? OR threat_type LIKE ?)"
        like = f"%{search}%"
        params.extend([like, like, like])
    query += " ORDER BY timestamp DESC"
    cur.execute(query, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_alert_by_id(alert_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM alerts WHERE id = ?", (alert_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def delete_alert(alert_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM alerts WHERE id = ?", (alert_id,))
    conn.commit()
    conn.close()


def update_alert_status(alert_id, status):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE alerts SET status = ? WHERE id = ?", (status, alert_id))
    conn.commit()
    conn.close()


def get_dashboard_stats():
    conn = get_connection()
    cur = conn.cursor()

    stats = {}
    cur.execute("SELECT COUNT(*) as c FROM alerts")
    stats["total_alerts"] = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) as c FROM alerts WHERE threat_type != 'Normal'")
    stats["total_threats"] = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) as c FROM alerts WHERE severity IN ('High','Critical') AND status = 'Open'")
    stats["high_risk_open"] = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) as c FROM alerts WHERE status = 'Open'")
    stats["open_alerts"] = cur.fetchone()["c"]

    cur.execute("SELECT threat_type, COUNT(*) as c FROM alerts GROUP BY threat_type")
    stats["by_type"] = {r["threat_type"]: r["c"] for r in cur.fetchall()}

    cur.execute("SELECT severity, COUNT(*) as c FROM alerts GROUP BY severity")
    stats["by_severity"] = {r["severity"]: r["c"] for r in cur.fetchall()}

    cur.execute("""
        SELECT substr(timestamp,1,10) as day, COUNT(*) as c
        FROM alerts GROUP BY day ORDER BY day
    """)
    stats["by_day"] = [{"day": r["day"], "count": r["c"]} for r in cur.fetchall()]

    cur.execute("SELECT AVG(confidence) as a FROM alerts")
    avg_conf = cur.fetchone()["a"]
    stats["avg_confidence"] = round(avg_conf, 3) if avg_conf else 0

    conn.close()
    return stats


def get_user(username):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def create_user(username, password, role="analyst"):
    """Create a new user account. Returns the new user id, or None if the
    username is already taken."""
    if get_user(username):
        return None
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
        (username, generate_password_hash(password), role, datetime.now().isoformat()),
    )
    conn.commit()
    user_id = cur.lastrowid
    conn.close()
    return user_id


def get_all_users():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, username, role, created_at FROM users ORDER BY id")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_user_by_id(user_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def update_user_role(user_id, role):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
    conn.commit()
    conn.close()


def delete_user(user_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()
