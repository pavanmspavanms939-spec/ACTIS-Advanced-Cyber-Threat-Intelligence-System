"""
Advanced Cyber Threat Intelligence System
------------------------------------------
Machine Learning training module.

Generates a realistic, feature-engineered synthetic network-traffic /
log dataset (six classes: Normal, DDoS, Malware, Phishing, Brute_Force,
Port_Scan) and trains a RandomForestClassifier to recognise them.

In a production deployment this module would instead be pointed at real
NetFlow/Zeek logs, endpoint EDR logs and OSINT/STIX-TAXII feeds. The
feature set, preprocessing pipeline and model interface are designed so
that swapping the data source does not require changing app.py.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)

FEATURE_NAMES = [
    "packet_count",       # packets in the flow/session
    "byte_count",         # total bytes transferred
    "duration",           # flow duration in seconds
    "src_port",           # source port
    "dst_port",           # destination port
    "syn_count",          # number of SYN packets (scan/flood indicator)
    "unique_dst_ips",     # distinct destination IPs contacted (scan indicator)
    "failed_logins",      # failed auth attempts (brute force indicator)
    "url_length",         # length of requested URL (phishing indicator)
    "entropy_score",      # payload/domain entropy (malware C2 / DGA indicator)
    "protocol_type",      # 0=TCP 1=UDP 2=ICMP 3=HTTP 4=HTTPS
    "avg_pkt_size",       # average packet size in bytes
]

CLASSES = ["Normal", "DDoS", "Malware", "Phishing", "Brute_Force", "Port_Scan"]

SEVERITY_MAP = {
    "Normal": "None",
    "Port_Scan": "Low",
    "Phishing": "Medium",
    "Brute_Force": "Medium",
    "Malware": "High",
    "DDoS": "Critical",
}


def _generate_class_samples(label, n):
    """Generate n synthetic feature rows for a given threat class using
    distribution parameters that mimic real-world traffic signatures."""
    if label == "Normal":
        data = {
            "packet_count": np.random.normal(120, 40, n).clip(1, None),
            "byte_count": np.random.normal(15000, 6000, n).clip(100, None),
            "duration": np.random.normal(30, 15, n).clip(0.1, None),
            "src_port": np.random.randint(1024, 65535, n),
            "dst_port": np.random.choice([80, 443, 22, 53, 3306], n),
            "syn_count": np.random.poisson(1, n),
            "unique_dst_ips": np.random.randint(1, 3, n),
            "failed_logins": np.random.poisson(0.05, n),
            "url_length": np.random.normal(35, 10, n).clip(5, None),
            "entropy_score": np.random.normal(3.2, 0.6, n).clip(0, 8),
            "protocol_type": np.random.choice([0, 1, 3, 4], n),
            "avg_pkt_size": np.random.normal(500, 150, n).clip(40, None),
        }
    elif label == "DDoS":
        data = {
            "packet_count": np.random.normal(15000, 4000, n).clip(500, None),
            "byte_count": np.random.normal(900000, 200000, n).clip(10000, None),
            "duration": np.random.normal(8, 4, n).clip(0.1, None),
            "src_port": np.random.randint(1, 65535, n),
            "dst_port": np.random.choice([80, 443, 53], n),
            "syn_count": np.random.normal(8000, 2000, n).clip(100, None),
            "unique_dst_ips": np.random.randint(1, 2, n),
            "failed_logins": np.random.poisson(0.02, n),
            "url_length": np.random.normal(20, 5, n).clip(5, None),
            "entropy_score": np.random.normal(2.0, 0.5, n).clip(0, 8),
            "protocol_type": np.random.choice([0, 1, 2], n),
            "avg_pkt_size": np.random.normal(60, 20, n).clip(20, None),
        }
    elif label == "Malware":
        data = {
            "packet_count": np.random.normal(400, 150, n).clip(1, None),
            "byte_count": np.random.normal(60000, 25000, n).clip(500, None),
            "duration": np.random.normal(180, 90, n).clip(1, None),
            "src_port": np.random.randint(1024, 65535, n),
            "dst_port": np.random.choice([4444, 8080, 6667, 443, 9001], n),
            "syn_count": np.random.poisson(3, n),
            "unique_dst_ips": np.random.randint(2, 12, n),
            "failed_logins": np.random.poisson(0.1, n),
            "url_length": np.random.normal(60, 20, n).clip(5, None),
            "entropy_score": np.random.normal(6.2, 0.8, n).clip(0, 8),
            "protocol_type": np.random.choice([0, 3, 4], n),
            "avg_pkt_size": np.random.normal(300, 100, n).clip(40, None),
        }
    elif label == "Phishing":
        data = {
            "packet_count": np.random.normal(60, 20, n).clip(1, None),
            "byte_count": np.random.normal(8000, 3000, n).clip(100, None),
            "duration": np.random.normal(15, 8, n).clip(0.1, None),
            "src_port": np.random.randint(1024, 65535, n),
            "dst_port": np.random.choice([80, 443], n),
            "syn_count": np.random.poisson(1, n),
            "unique_dst_ips": np.random.randint(1, 3, n),
            "failed_logins": np.random.poisson(0.3, n),
            "url_length": np.random.normal(140, 40, n).clip(20, None),
            "entropy_score": np.random.normal(5.0, 0.7, n).clip(0, 8),
            "protocol_type": np.random.choice([3, 4], n),
            "avg_pkt_size": np.random.normal(450, 120, n).clip(40, None),
        }
    elif label == "Brute_Force":
        data = {
            "packet_count": np.random.normal(500, 150, n).clip(10, None),
            "byte_count": np.random.normal(25000, 8000, n).clip(500, None),
            "duration": np.random.normal(60, 25, n).clip(1, None),
            "src_port": np.random.randint(1024, 65535, n),
            "dst_port": np.random.choice([22, 21, 3389, 3306], n),
            "syn_count": np.random.poisson(4, n),
            "unique_dst_ips": np.random.randint(1, 2, n),
            "failed_logins": np.random.normal(35, 12, n).clip(3, None),
            "url_length": np.random.normal(15, 5, n).clip(5, None),
            "entropy_score": np.random.normal(3.0, 0.5, n).clip(0, 8),
            "protocol_type": np.random.choice([0], n),
            "avg_pkt_size": np.random.normal(80, 25, n).clip(20, None),
        }
    else:  # Port_Scan
        data = {
            "packet_count": np.random.normal(800, 200, n).clip(50, None),
            "byte_count": np.random.normal(40000, 10000, n).clip(500, None),
            "duration": np.random.normal(10, 5, n).clip(0.1, None),
            "src_port": np.random.randint(1024, 65535, n),
            "dst_port": np.random.randint(1, 65535, n),
            "syn_count": np.random.normal(700, 180, n).clip(50, None),
            "unique_dst_ips": np.random.randint(1, 3, n),
            "failed_logins": np.random.poisson(0.02, n),
            "url_length": np.random.normal(10, 3, n).clip(5, None),
            "entropy_score": np.random.normal(2.5, 0.4, n).clip(0, 8),
            "protocol_type": np.random.choice([0, 1], n),
            "avg_pkt_size": np.random.normal(50, 15, n).clip(20, None),
        }

    df = pd.DataFrame(data)
    df["label"] = label
    return df


def generate_dataset(n_per_class=1500):
    frames = [_generate_class_samples(c, n_per_class) for c in CLASSES]
    df = pd.concat(frames, ignore_index=True)
    df = df.sample(frac=1, random_state=RANDOM_STATE).reset_index(drop=True)
    return df


def train_and_save(model_dir=None):
    model_dir = model_dir or os.path.dirname(os.path.abspath(__file__))

    df = generate_dataset()
    X = df[FEATURE_NAMES]
    y = df["label"]

    le = LabelEncoder()
    y_enc = le.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y_enc, test_size=0.2, random_state=RANDOM_STATE, stratify=y_enc
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    clf = RandomForestClassifier(
        n_estimators=200,
        max_depth=14,
        min_samples_split=4,
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    clf.fit(X_train_scaled, y_train)

    y_pred = clf.predict(X_test_scaled)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, target_names=le.classes_)

    print(f"Model trained. Test accuracy: {acc:.4f}")
    print(report)

    joblib.dump(clf, os.path.join(model_dir, "threat_model.pkl"))
    joblib.dump(scaler, os.path.join(model_dir, "scaler.pkl"))
    joblib.dump(le, os.path.join(model_dir, "label_encoder.pkl"))

    with open(os.path.join(model_dir, "metrics.txt"), "w") as f:
        f.write(f"Test Accuracy: {acc:.4f}\n\n{report}")

    return acc


if __name__ == "__main__":
    train_and_save()
