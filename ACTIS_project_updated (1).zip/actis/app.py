"""
Advanced Cyber Threat Intelligence System
------------------------------------------
Flask application entry point.

Implements every feature listed in the project synopsis:
 - Secure login (session-based)
 - Real-time traffic simulation & AI/ML-based threat detection
 - Risk score / confidence level per prediction
 - MITRE ATT&CK correlation
 - Alert generation & threat-history management (view/search/filter/delete)
 - Interactive dashboard (Chart.js)
 - PDF / Excel report export
"""

import io
import os
import random
from datetime import datetime, timedelta

import joblib
import numpy as np
import pandas as pd
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_file, jsonify
)
from werkzeug.security import check_password_hash

import database as db
from ml_model.train_model import FEATURE_NAMES, CLASSES, SEVERITY_MAP

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-in-production")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "ml_model")

db.init_db()

# Load trained model artifacts once at startup
model = joblib.load(os.path.join(MODEL_DIR, "threat_model.pkl"))
scaler = joblib.load(os.path.join(MODEL_DIR, "scaler.pkl"))
label_encoder = joblib.load(os.path.join(MODEL_DIR, "label_encoder.pkl"))


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
def login_required(view):
    def wrapped(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    wrapped.__name__ = view.__name__
    return wrapped


def admin_required(view):
    def wrapped(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        if session.get("role") != "administrator":
            flash("Administrator access required.", "danger")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    wrapped.__name__ = view.__name__
    return wrapped


@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("dashboard") if "user" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = db.get_user(username)
        if user and check_password_hash(user["password_hash"], password):
            session["user"] = user["username"]
            session["role"] = user["role"]
            flash("Login successful.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not username or not password:
            flash("Username and password are required.", "danger")
        elif len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
        elif password != confirm_password:
            flash("Passwords do not match.", "danger")
        elif db.get_user(username):
            flash("That username is already taken.", "danger")
        else:
            db.create_user(username, password, role="analyst")
            flash("Account created successfully. Please sign in.", "success")
            return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    stats = db.get_dashboard_stats()
    recent = db.get_alerts()[:8]
    return render_template("dashboard.html", stats=stats, recent=recent)


@app.route("/api/dashboard-stats")
@login_required
def api_dashboard_stats():
    return jsonify(db.get_dashboard_stats())


# ---------------------------------------------------------------------------
# Admin panel: user management (administrator role only)
# ---------------------------------------------------------------------------
@app.route("/admin")
@admin_required
def admin_panel():
    users = db.get_all_users()
    return render_template("admin.html", users=users)


@app.route("/admin/users/add", methods=["POST"])
@admin_required
def admin_add_user():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    role = request.form.get("role", "analyst")
    if role not in ("analyst", "administrator"):
        role = "analyst"

    if not username or not password:
        flash("Username and password are required.", "danger")
    elif len(password) < 6:
        flash("Password must be at least 6 characters.", "danger")
    elif db.get_user(username):
        flash("That username is already taken.", "danger")
    else:
        db.create_user(username, password, role=role)
        flash(f"User '{username}' created.", "success")
    return redirect(url_for("admin_panel"))


@app.route("/admin/users/<int:user_id>/role", methods=["POST"])
@admin_required
def admin_update_role(user_id):
    role = request.form.get("role", "analyst")
    if role not in ("analyst", "administrator"):
        role = "analyst"
    target = db.get_user_by_id(user_id)
    if target and target["username"] == session["user"]:
        flash("You can't change your own role.", "danger")
    elif target:
        db.update_user_role(user_id, role)
        if target["username"] == session.get("user"):
            session["role"] = role
        flash(f"Role updated for '{target['username']}'.", "success")
    return redirect(url_for("admin_panel"))


@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def admin_delete_user(user_id):
    target = db.get_user_by_id(user_id)
    if target and target["username"] == session["user"]:
        flash("You can't delete your own account.", "danger")
    elif target:
        db.delete_user(user_id)
        flash(f"User '{target['username']}' deleted.", "info")
    return redirect(url_for("admin_panel"))


# ---------------------------------------------------------------------------
# Threat detection engine
# ---------------------------------------------------------------------------
def risk_score_from(confidence, threat_type):
    """Combine model confidence with the class's inherent severity weight
    to produce a 0-100 risk score, per synopsis objective 5."""
    base_weight = {
        "Normal": 0.0, "Port_Scan": 0.3, "Phishing": 0.55,
        "Brute_Force": 0.6, "Malware": 0.85, "DDoS": 1.0,
    }.get(threat_type, 0.5)
    return round(confidence * base_weight * 100, 2)


def simulate_traffic_sample():
    """Generates one random plausible traffic sample - stands in for a live
    packet-capture / log-tailing feed (Scapy/PyShark in the full deployment)."""
    true_class = random.choices(
        CLASSES, weights=[55, 8, 10, 10, 9, 8], k=1
    )[0]
    from ml_model.train_model import _generate_class_samples
    row = _generate_class_samples(true_class, 1).iloc[0]
    features = {f: float(row[f]) for f in FEATURE_NAMES}
    ip = lambda: ".".join(str(random.randint(1, 254)) for _ in range(4))
    return features, ip(), ip()


def predict(features: dict):
    X = pd.DataFrame([features])[FEATURE_NAMES]
    X_scaled = scaler.transform(X)
    probs = model.predict_proba(X_scaled)[0]
    pred_idx = int(np.argmax(probs))
    threat_type = label_encoder.inverse_transform([pred_idx])[0]
    confidence = float(probs[pred_idx])
    severity = SEVERITY_MAP.get(threat_type, "Medium")
    risk = risk_score_from(confidence, threat_type)
    return threat_type, severity, confidence, risk


@app.route("/detect", methods=["GET", "POST"])
@login_required
def detect():
    result = None
    if request.method == "POST":
        mode = request.form.get("mode", "simulate")
        if mode == "simulate":
            features, src_ip, dst_ip = simulate_traffic_sample()
        else:
            try:
                features = {f: float(request.form.get(f, 0)) for f in FEATURE_NAMES}
            except ValueError:
                flash("Please enter valid numeric values for all fields.", "danger")
                return render_template("detect.html", feature_names=FEATURE_NAMES, result=None)
            src_ip = request.form.get("src_ip") or "192.168.1.10"
            dst_ip = request.form.get("dst_ip") or "10.0.0.5"

        threat_type, severity, confidence, risk = predict(features)
        alert_id = db.insert_alert(
            src_ip, dst_ip, threat_type, severity, confidence, risk,
            details=str(features)
        )
        result = {
            "id": alert_id, "threat_type": threat_type, "severity": severity,
            "confidence": round(confidence * 100, 2), "risk_score": risk,
            "src_ip": src_ip, "dst_ip": dst_ip, "features": features,
        }
        mitre_id, mitre_name = db.MITRE_MAP.get(threat_type, ("-", "Unknown"))
        result["mitre_id"] = mitre_id
        result["mitre_name"] = mitre_name
        result["action"] = db.RECOMMENDED_ACTIONS.get(threat_type)

    return render_template("detect.html", feature_names=FEATURE_NAMES, result=result)


@app.route("/detect/bulk-simulate", methods=["POST"])
@login_required
def bulk_simulate():
    """Simulate N traffic samples at once - useful for populating the
    dashboard / demoing real-time monitoring."""
    n = int(request.form.get("count", 20))
    n = max(1, min(n, 200))
    for _ in range(n):
        features, src_ip, dst_ip = simulate_traffic_sample()
        threat_type, severity, confidence, risk = predict(features)
        db.insert_alert(src_ip, dst_ip, threat_type, severity, confidence, risk,
                         details=str(features))
    flash(f"Simulated and analyzed {n} traffic samples.", "success")
    return redirect(url_for("alerts_view"))


# ---------------------------------------------------------------------------
# Alerts / Threat history
# ---------------------------------------------------------------------------
@app.route("/alerts")
@login_required
def alerts_view():
    threat_type = request.args.get("threat_type", "All")
    severity = request.args.get("severity", "All")
    status = request.args.get("status", "All")
    search = request.args.get("search", "").strip()

    alerts = db.get_alerts(threat_type, severity, status, search or None)
    return render_template(
        "alerts.html", alerts=alerts, classes=["All"] + CLASSES,
        severities=["All", "None", "Low", "Medium", "High", "Critical"],
        statuses=["All", "Open", "Investigating", "Resolved"],
        filters={"threat_type": threat_type, "severity": severity,
                 "status": status, "search": search}
    )


@app.route("/alerts/<int:alert_id>/delete", methods=["POST"])
@login_required
def delete_alert(alert_id):
    db.delete_alert(alert_id)
    flash("Alert deleted.", "info")
    return redirect(url_for("alerts_view"))


@app.route("/alerts/<int:alert_id>/status", methods=["POST"])
@login_required
def update_status(alert_id):
    status = request.form.get("status", "Open")
    db.update_alert_status(alert_id, status)
    flash("Alert status updated.", "success")
    return redirect(url_for("alerts_view"))


# ---------------------------------------------------------------------------
# Reports: PDF & Excel export
# ---------------------------------------------------------------------------
@app.route("/reports")
@login_required
def reports():
    stats = db.get_dashboard_stats()
    return render_template("reports.html", stats=stats)


@app.route("/reports/export/excel")
@login_required
def export_excel():
    alerts = db.get_alerts()
    df = pd.DataFrame(alerts)
    if df.empty:
        df = pd.DataFrame(columns=[
            "id", "timestamp", "source_ip", "dest_ip", "threat_type",
            "severity", "confidence", "risk_score", "mitre_id",
            "mitre_name", "recommended_action", "status"
        ])
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Threat Alerts")
    buf.seek(0)
    fname = f"ACTIS_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return send_file(buf, as_attachment=True, download_name=fname,
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/reports/export/pdf")
@login_required
def export_pdf():
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    )
    from reportlab.lib.styles import getSampleStyleSheet

    alerts = db.get_alerts()
    stats = db.get_dashboard_stats()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                             leftMargin=1.5 * cm, rightMargin=1.5 * cm)
    styles = getSampleStyleSheet()
    elements = []

    elements.append(Paragraph("Advanced Cyber Threat Intelligence System", styles["Title"]))
    elements.append(Paragraph(f"Security Report — Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                               styles["Normal"]))
    elements.append(Spacer(1, 12))

    summary_data = [
        ["Total Alerts", stats["total_alerts"]],
        ["Total Threats Detected", stats["total_threats"]],
        ["Open High/Critical Alerts", stats["high_risk_open"]],
        ["Average Model Confidence", f'{stats["avg_confidence"]*100:.1f}%'],
    ]
    t = Table(summary_data, colWidths=[9 * cm, 6 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#0b1f3a")),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(t)
    elements.append(Spacer(1, 16))
    elements.append(Paragraph("Recent Threat Alerts", styles["Heading2"]))
    elements.append(Spacer(1, 8))

    table_data = [["ID", "Time", "Src IP", "Type", "Severity", "Risk", "Status"]]
    for a in alerts[:60]:
        table_data.append([
            a["id"], a["timestamp"][:16], a["source_ip"], a["threat_type"],
            a["severity"], f'{a["risk_score"]}', a["status"]
        ])
    t2 = Table(table_data, colWidths=[1.3 * cm, 3.2 * cm, 3 * cm, 2.8 * cm, 2.3 * cm, 1.8 * cm, 2.5 * cm])
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b1f3a")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
    ]))
    elements.append(t2)

    doc.build(elements)
    buf.seek(0)
    fname = f"ACTIS_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    return send_file(buf, as_attachment=True, download_name=fname, mimetype="application/pdf")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
